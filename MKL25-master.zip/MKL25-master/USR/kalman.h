#ifndef  _KALMAN_FILTER_H
#define  _KALMAN_FILTER_H

typedef struct {
    float x[2];     /* state: [0]-angle [1]-diffrence of angle, 2x1 */
    float A[2][2];  /* X(n)=A*X(n-1)+U(n),U(n)~N(0,q), 2x2 */
    float H[2];     /* Z(n)=H*X(n)+W(n),W(n)~N(0,r), 1x2   */
    float q[2];     /* process(predict) noise convariance,2x1 [q0,0; 0,q1] */
    float r;        /* measure noise convariance */
    float p[2][2];  /* estimated error convariance,2x2 [p0 p1; p2 p3] */
    float gain[2];  /* 2x1 */
} kalmanStateTypeDef;

// ���ܺ���
void kalmanInit(kalmanStateTypeDef *state, float *init_x, float (*init_p)[2]);
void kalmanFilter(kalmanStateTypeDef *state, float zMeasure);

#endif
