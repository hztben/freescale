
#ifndef __APP_H__
#define __APP_H__

#include "stdint.h"

void speedControl(void);
void directionControl(void);

void CCD_Image_Process(uint8_t * ImageData);
void CCD_FAR_Image_Process(uint8_t *ImageData);

void Cpu_Delay200nm(uint32_t t);

void Send_Data(unsigned char * ImageData);
void SendHex(unsigned char hex);
void Uart1_Send_Byte(uint8_t val);

float get_center(void);
void get_speed(void);
void ModelSwitch(void);
void StartDelay(void);

#endif
