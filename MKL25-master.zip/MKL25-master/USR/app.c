#include "app.h"
#include "user.h"
#include "adc.h"
#include "pwm.h"
#include "delay.h"
#include "counter.h"
#include "led.h"
#define THRESHOLD  50 //��ֵ
#define MAXSIZE 128   //�������
#define CENTER_CAR 64
#define SPEED_RATIO 0.0195312
/*  KP_Dir = -40  KD_Dir = -80  Set_Spd_All = 150  (int32_t)(5*err)  widen = 58*/
/*  KP_Dir = -40  KD_Dir = -80  Set_Spd_All = 160  (int32_t)(5*err)  widen = 58*/
/*  KP_Dir = -50  KD_Dir = -80  Set_Spd_All = 170  (int32_t)(5*err)  widen = 64*/


extern unsigned char Pixel[128];
extern unsigned char Pixel_Far[128];
float black_center = MAXSIZE / 2;
float err = 0;
float last_err = 0;
float KP_Dir = -50;//40  50
float KD_Dir = -80;//60  80

int32_t PI_Out_left = 0;
int32_t PI_Out_right = 0;
int32_t Set_Spd_All = 180;//�ٶ� 170
float Motor_Spd_P =35;//35  8
float Motor_Spd_I =0;//  0
int32_t PI_SpeedOld_left = 0;
int32_t PI_SpeedNew_left = 0;
int32_t PI_SpeedOld_right = 0;
int32_t PI_SpeedNew_right = 0;	
int32_t PI_SpeedKeep_left = 0;
int32_t PI_SpeedKeep_right = 0;
int32_t PI_Speed_dif = 15000;
int32_t counter_left;
int32_t counter_right;
uint32_t speed_P_left;
uint32_t speed_I_left;
uint32_t spd_left;
int32_t Spd_err_left;
uint32_t speed_P_right;
uint32_t speed_I_right;
uint32_t spd_right;
int32_t Spd_err_right;

float widen = 64;		//��������  58  68
float last_REdge;
float last_LEdge;
int32_t mid_begin=64;

unsigned char stop_flag = 0;

int32_t spd_fast = 200;
int32_t spd_slow = 150;

uint8_t sw1 = 0;
uint8_t sw2 = 0;
uint8_t sw3 = 0;


void speedControl(){
	float nValue_left;
	float nValue_right;
	
	counter_right = Counter0_Read();
	counter_left = Counter1_Read();
	spd_left = counter_left;
	spd_right = counter_right;
	Spd_err_left = Set_Spd_All - spd_left; //* SPEED_RATIO;
	Spd_err_right = Set_Spd_All - spd_right; //* SPEED_RATIO;
	speed_P_left = (int32_t)(Spd_err_left * Motor_Spd_P);
	speed_P_right = (int32_t)(Spd_err_right * Motor_Spd_P);
	speed_I_left = (int32_t)(Spd_err_left * Motor_Spd_I);
	speed_I_right = (int32_t)(Spd_err_right * Motor_Spd_I);
	PI_SpeedOld_left = PI_SpeedNew_left;
	PI_SpeedOld_right = PI_SpeedNew_right;
	PI_SpeedKeep_left += speed_I_left;
	PI_SpeedKeep_right += speed_I_right;
	if(PI_SpeedKeep_left > 1500) {
		PI_SpeedKeep_left = 1500;
	}
	if(PI_SpeedKeep_right > 1500) {
		PI_SpeedKeep_right = 1500;
	}
	PI_SpeedNew_left = speed_P_left + PI_SpeedKeep_left;
	PI_SpeedNew_right = speed_P_right + PI_SpeedKeep_right;
	nValue_left = PI_SpeedNew_left - PI_SpeedOld_left;
	nValue_right = PI_SpeedNew_right - PI_SpeedOld_right;
	PI_Out_left = nValue_left + PI_SpeedOld_left;
	PI_Out_right = nValue_right + PI_SpeedOld_right;
	
	Counter0_Clear();
	Counter1_Clear();
	
	if(stop_flag == 0 ){
		PWMOutput(PTA12,2800 + PI_Out_right - (int32_t)(12*err));//4
		PWMOutput(PTA13,2800 + PI_Out_left + (int32_t)(12*err));
	}
	else{
		PWMOutput(PTA12,2500);
		PWMOutput(PTA13,2500);
	}
	
}

void directionControl(){  
    int32_t fValue ; 
    black_center = get_center();
    err = black_center - CENTER_CAR ;
    fValue =(int32_t)(KP_Dir * err + KD_Dir * (err - last_err));
	  fValue = 5400 + fValue;   
		if(fValue > 6300)        //�޷��ĳɶ����ת���ֵ
			fValue = 6300;
		if(fValue < 4400)        //�޷��ĳɶ����ת���ֵ
			fValue = 4400;
		PWMOutput(PTA5,fValue);
	  last_err = err;
}

float get_center(void){
  unsigned char i;
  float REdge = 123;
	float LEdge = 5;
	unsigned char Found_R = 0;
	unsigned char Found_L = 0;
  unsigned char Rbound_L = 0;
	unsigned char Lbound_R = 0;
	for(i=mid_begin;i<115;i++){	
		if(*(Pixel+i)-*(Pixel+i+3)>THRESHOLD){//�������ұ߽�
			REdge=i;
			Found_R=1;
			break;
		 }
		if(*(Pixel+i)-*(Pixel+i-3)>THRESHOLD){//������������
			Rbound_L = 1;
			break;
		}
	}
	for(i=mid_begin;i>13;i--){
		if(*(Pixel+i)-*(Pixel+i-3)>THRESHOLD){//��������߽�
			LEdge=i;
			Found_L=1;
			break;
		}
		if(*(Pixel+i)-*(Pixel+i+3)>THRESHOLD){//������������
			Lbound_R = 1;
			break;
		}
	}
  
	if(Found_L == 0 || Found_R == 0){ 
    if((Found_R==0)&&(Lbound_R==1)){//������������
			for(i=mid_begin;i>13;i--){
				if(*(Pixel+i)-*(Pixel+i+3)>THRESHOLD){
					REdge=i;
					Found_R = 1;
          break;
				}
			}
		}
		if((Found_L==0)&&(Rbound_L==1)){//������������
			for(i=mid_begin;i<115;i++){
				if(*(Pixel+i)-*(Pixel+i-3)>THRESHOLD){
					LEdge=i;
					Found_L = 1;
          break;
				}
			}
		}
		if((Found_R == 1) && (Found_L == 0)){
			LEdge = REdge - widen;
		}
		if((Found_L == 1) && (Found_R == 0)){
			REdge = LEdge + widen;
		}
		if((Found_R == 0) && (Found_L == 0)){
			for(i = 25; i < 103; i++){
				if(*(Pixel+i) < 70){
					//stop_flag = 1;
					LEdge = last_LEdge;
					REdge = last_REdge;
					break;
				}				
			}
		}
	}
	if(Rbound_L == 1 && Lbound_R == 1){
		if(last_err > 0){
			REdge = LEdge + widen;
		}
		if(last_err < 0){
			LEdge = REdge - widen;
		}
	}
	/*if((REdge - last_REdge > 70) || (REdge - last_REdge < -70)){
		REdge = LEdge + widen;
	}
	if((LEdge - last_LEdge > 70) || (LEdge - last_LEdge < -70)){
		LEdge = REdge - widen;
	}*/
	mid_begin=(LEdge+REdge)/2;
	if((mid_begin<MAXSIZE /2+45)&&(mid_begin>MAXSIZE /2-45)&&(Found_R==1||Found_L==1)){
		mid_begin=(LEdge+REdge)/2;
	}
	else{
		mid_begin=MAXSIZE /2;
  }
	if(REdge<LEdge){
		REdge=last_REdge;
	  LEdge=last_LEdge;
	}
	last_REdge=REdge;
  last_LEdge=LEdge;
	/*mid_begin=(LEdge+REdge)/2;
	if(mid_begin >= 123){
		mid_begin = 123;
	}
	if(mid_begin <= 5){
		mid_begin = 5;
	}*/
  return (float)((LEdge + REdge)/2);		 
}

void get_speed(){
	unsigned char i;
	float err_Far = 0;
  float REdge_Far = 123;
	float LEdge_Far = 5;
	unsigned char Found_R_Far = 0;
	unsigned char Found_L_Far = 0;
	unsigned char crossroad_flag = 1;
	for(i=64;i<100;i++){	
		if(*(Pixel_Far+i)-*(Pixel_Far+i+3)>THRESHOLD){//�������ұ߽�
			REdge_Far=i;
			Found_R_Far=1;
			break;
		 }
	}
	for(i=64;i>28;i--){
		if(*(Pixel_Far+i)-*(Pixel_Far+i-3)>THRESHOLD){//��������߽�
			LEdge_Far=i;
			Found_L_Far=1;
			break;
		}
	}
	if((Found_R_Far == 1) && (Found_L_Far == 1)){
		err_Far = (((REdge_Far + LEdge_Far) / 2) - 64);
	}
	if((Found_R_Far == 0) && (Found_L_Far == 0)){
		for(i = 28; i < 100; i++){
			if(*(Pixel_Far+i) < 65){
				crossroad_flag = 0;
				break;		
			}
		}
		if(crossroad_flag == 1){
			Found_R_Far = 1;
			Found_L_Far = 1;
		}
	}
	if((err_Far < 6) && (err_Far > -6) && (err < 6) && (err > -6) && (Found_R_Far == 1) && (Found_L_Far == 1)){
		Set_Spd_All = spd_fast;
	}
	else{
		Set_Spd_All = spd_slow;
	}
}

void ModelSwitch(){
	sw1 = GPIO_ReadInputDataBit(PTB,1);
	sw2 = GPIO_ReadInputDataBit(PTB,2);
	sw3 = GPIO_ReadInputDataBit(PTB,3);
	if((sw1 == 1) && (sw2 == 1) && (sw3 == 1)){
		KP_Dir = -40;
		KD_Dir = -80;
		spd_fast = 200;
		spd_slow = 150;
		widen = 60;
	}
	if((sw1 == 1) && (sw2 == 1) && (sw3 == 0)){
		KP_Dir = -40;
		KD_Dir = -80;
		spd_fast = 230;
		spd_slow = 160;
		widen = 60;
	}
	if((sw1 == 1) && (sw2 == 0) && (sw3 == 1)){
		KP_Dir = -42;
		KD_Dir = -80;
		spd_fast = 240;
		spd_slow = 170;
		widen = 62;
	}
}

void CCD_Image_Process(uint8_t *ImageData){
	unsigned char i;
  GPIO_SetBits(PTD,4);
  Cpu_Delay200nm(1);
  GPIO_SetBits(PTD,3);
  Cpu_Delay200nm(1);
  GPIO_ResetBits(PTD,4);
  Cpu_Delay200nm(1);
  DelayUs(10);//Delay 10us for sample the first pixel
  *ImageData++ =(uint8_t)(ADC_GetValue(0)>>8);
	GPIO_ResetBits(PTD,3);
	for(i=0; i<127; i++){
		Cpu_Delay200nm(1);
    GPIO_SetBits(PTD,3);
    Cpu_Delay200nm(1);
		*ImageData++ =(uint8_t)(ADC_GetValue(0)>>8);
		GPIO_ResetBits(PTD,3);
	} 
  Cpu_Delay200nm(1);
  GPIO_SetBits(PTD,3);  
  Cpu_Delay200nm(1);
  GPIO_ResetBits(PTD,3);   
}

void CCD_FAR_Image_Process(uint8_t *ImageData){
	unsigned char i;
  GPIO_SetBits(PTD,6);
  Cpu_Delay200nm(1);
  GPIO_SetBits(PTD,5);
  Cpu_Delay200nm(1);
  GPIO_ResetBits(PTD,6);
  Cpu_Delay200nm(1);
  DelayUs(10);//Delay 10us for sample the first pixel
  *ImageData++ =(uint8_t)(ADC_GetValue(1)>>8);
	GPIO_ResetBits(PTD,5);
	for(i=0; i<127; i++){
		Cpu_Delay200nm(1);
    GPIO_SetBits(PTD,5);
    Cpu_Delay200nm(1);
		*ImageData++ =(uint8_t)(ADC_GetValue(1)>>8);
		GPIO_ResetBits(PTD,5);
	} 
  Cpu_Delay200nm(1);
  GPIO_SetBits(PTD,5);  
  Cpu_Delay200nm(1);
  GPIO_ResetBits(PTD,5);   
}

void StartDelay(){
	unsigned char i;
	for(i = 0; i < 40; i ++)
		DelayMs(100);
}

void Cpu_Delay200nm(uint32_t t){
	uint32_t j;
	for(j = t; j > 0; j --)
	{
	}
}

void Send_Data(unsigned char * ImageData){
  
	 
	  unsigned char i;
    unsigned char crc = 0;

    /* Send Data */
    Uart1_Send_Byte('*');
    Uart1_Send_Byte('L');
    Uart1_Send_Byte('D');
    
    SendHex(0);
    SendHex(0);
    SendHex(0);
    SendHex(0);

    for(i=0; i<128; i++) {
      SendHex(*ImageData++);
    }

    SendHex(crc);
    Uart1_Send_Byte('#');
}

void SendHex(unsigned char hex) {
  unsigned char temp;
  temp = hex >> 4;
  if(temp < 10) {
   Uart1_Send_Byte(temp + '0');
  } else {
   Uart1_Send_Byte(temp - 10 + 'A');
  }
  temp = hex & 0x0F;
  if(temp < 10) {
   Uart1_Send_Byte(temp + '0');
  } else {
   Uart1_Send_Byte(temp - 10 + 'A');
  }
}

void Uart1_Send_Byte(uint8_t val){
	while(!(UART1->S1&0x80));
	UART1->D=val;
}
