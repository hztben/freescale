#include "user.h"
#include "led.h"
#include "stdint.h"
#include "adc.h"
#include "gpio.h"
#include "uart.h"
#include "pit.h"

static const PeripheralMapTypeDef ADC_Check_Maps[] = 
{
	{0, 4, 1,20, 2, 0, 0},  //�˿�  ADC0_DP0_PE20_DM0_PE21  channel 0
	{0, 4, 1,16, 2, 1, 0},  //			ADC0_DP1_PE16_DM1_PE17  				1
	{0, 4, 1,18, 2, 2, 0},  //			ADC0_DP2_PE18_DM2_PE19  				2
	{0, 4, 1,22, 2, 3, 0},  //			ADC0_DP3_PE22_DM3_PE23  				3
	{0, 4, 1,16, 1, 1, 0},  //			ADC0_SE1A_PE16 				  				4
	{0, 4, 1,17, 1, 5, 0},  //			ADC0_SE5A_PE17 				  				5
	{0, 4, 1,18, 1, 0, 0},  //			ADC0_SE2A_PE18 				  				6
	{0, 4, 1,19, 1, 6, 0},  //			ADC0_SE6A_PE19 				  				7
	{0, 4, 1,20, 1, 0, 0},  //			ADC0_SE0A_PE20 									8
	{0, 4, 1,21, 1, 4, 0},  //			ADC0_SE4A_PE21 									9
	{0, 4, 1,22, 1, 3, 0},  //			ADC0_SE3A_PE22 									10
	{0, 4, 1,23, 1, 7, 0},  //			ADC0_SE7A_PE23 									11
	{0, 4, 1,29, 1, 4, 1},  //			ADC0_SE4B_PE29 									12
	{0, 4, 1,30, 1,23, 0},  //			ADC0_SE23A_PE30 								13
	{0, 1, 1, 0, 1, 8, 0},  //			ADC0_SE8A_PB0 									14
	{0, 1, 1, 1, 1, 9, 0},  //			ADC0_SE9A_PB1 									15
	{0, 1, 1, 2, 1,12, 0},  //			ADC0_SE12A_PB2 									16
	{0, 1, 1, 3, 1,13, 0},  //			ADC0_SE13A_PB3 									17
	{0, 2, 1, 0, 1,14, 0},  //			ADC0_SE14A_PC0 									18
	{0, 2, 1, 1, 1,15, 0},  //			ADC0_SE15A_PC1 									19
	{0, 2, 1, 2, 1,11, 0},  //			ADC0_SE11A_PC2 									20
	{0, 3, 1, 1, 1, 5, 1},  //			ADC0_SE5B_PD1 									21
	{0, 3, 1, 5, 1, 6, 1},  //			ADC0_SE6B_PD5 									22
	{0, 3, 1, 6, 1, 7, 1},  //			ADC0_SE7B_PD6 									23
};

const uint8_t channel_index[]={8,9,11,10,12,15,16,17};

uint32_t ADC_CalxMap(uint8_t chl){
	uint32_t value = 0;
	value =   ADC_Check_Maps[chl].m_ModuleIndex<<0;
	value |=  ADC_Check_Maps[chl].m_PortIndex <<3;
	value |=  ADC_Check_Maps[chl].m_MuxIndex<<6;
	value |=  ADC_Check_Maps[chl].m_PinBaseIndex<<9;
	value |=  ADC_Check_Maps[chl].m_PinCntIndex<<14;
	value |=  ADC_Check_Maps[chl].m_ChlIndex<<17;
	value |=  ADC_Check_Maps[chl].m_SpecDefine1<<22;
	return value;
}

//======================================================================
//��ȡADC���źź���
//��ڣ�ͨ��(channel):
//���أ��ź�ֵ
//======================================================================
uint32_t ADC_GetValue(uint8_t index){
	return ADC_GetConversionValue(ADC_CalxMap(channel_index[index]));
}

//ADC��ʼ������
void ADC_userInit(void){
	ADC_InitTypeDef adc_initer;
	uint8_t i = 0;
	for (i = 0; i < 2; ++ i){
		adc_initer.ADCxMap = ADC_CalxMap(channel_index[i]);
		adc_initer.ADC_Precision = ADC_PRECISION_16BIT;
		adc_initer.ADC_TriggerSelect = ADC_TRIGGER_SW;
		ADC_Init(&adc_initer);
	}
}


//======================================================================
// ��ڲ�����GPIO:PTA:A�˿� PTB:B�˿� PTC:C�˿� PTD:D�˿� PTE:E�˿�
//			 		 Pin������
//					 Mode:GPIO_Mode_IN_FLOATING  ��������
//  							GPIO_Mode_IPD				   ��������
//  							GPIO_Mode_IPU          ��������
//  							GPIO_Mode_OOD          ��©���
//  							GPIO_Mode_OPP          �������
// ���ز�������
// ʵ��GPIO�ڵĳ�ʼ��
//======================================================================
void GPIO_userInit(GPIO_Type *GPIO,uint16_t Pin,GPIO_Mode_TypeDef Mode){
	
	GPIO_InitTypeDef GPIO_InitStruct1;
	
	GPIO_InitStruct1.GPIO_Pin = Pin;
	GPIO_InitStruct1.GPIO_InitState = Bit_RESET;
	GPIO_InitStruct1.GPIO_IRQMode = GPIO_IT_DISABLE;
	GPIO_InitStruct1.GPIO_Mode = Mode;
	GPIO_InitStruct1.GPIOx = GPIO;
	GPIO_Init(&GPIO_InitStruct1);
	
}

//PIT��ʼ������
void PIT_userInit(void){
	PIT_InitTypeDef pit_initer;
	pit_initer.PITx = PIT0;
	pit_initer.PIT_Interval = 10; //��λMS
	PIT_Init(&pit_initer);
}

//��ʱ��
uint8_t timer(void){
	static uint8_t cnt = 0;
	ITStatus state = PIT_GetITStatus(PIT0, PIT_IT_TIF);
	if(cnt==5) { cnt = 0; }
 	if(state == SET){
		++cnt;
		
		
 		PIT_ClearITPendingBit(PIT0, PIT_IT_TIF);
 	}
	return cnt;
}
