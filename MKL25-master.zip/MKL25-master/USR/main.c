#include "gpio.h"
#include "uart.h"
#include "delay.h"
#include "led.h"
#include "dma.h"
#include "spi.h"
#include "pit.h"
#include "adc.h"
#include "i2c.h"
#include "isr.h"
#include "pwm.h"
#include "stdio.h"
#include "user.h"
#include "app.h"
#include "counter.h"

unsigned char Pixel[128];
unsigned char Pixel_Far[128];

int main(void)
{
	//unsigned char Finish_flag;
	//unsigned char send_data_cnt = 0;
  //������ȷ������ⲿ�����Ƿ��Ӧ��8M���������ClockSource_EX8M��
	//50M���������ClockSource_EX50M����ƵƵ����ʹ�� go to�鿴��������
  SystemClockSetup(ClockSource_EX50M,CoreClock_100M);
	UART_PortInit(UART0_RX_PD06_TX_PD07,115200);
	UART_PortInit(UART1_RX_PE01_TX_PE00,9600);
  DelayInit();
	ledInit(PTB,0);
	GPIO_userInit(PTB,1,GPIO_Mode_IPU);
	GPIO_userInit(PTB,2,GPIO_Mode_IPU);
	GPIO_userInit(PTB,3,GPIO_Mode_IPU);
	GPIO_userInit(PTD,3,GPIO_Mode_OPP);
	GPIO_userInit(PTD,4,GPIO_Mode_OPP);
	GPIO_userInit(PTD,5,GPIO_Mode_OPP);
	GPIO_userInit(PTD,6,GPIO_Mode_OPP);
	PWMPortInit(PTA,12);
	PWMPortInit(PTA,13);
	PWMPortInit(PTA,5);
  DisableInterrupts();
	
	PWMInit(PTA12,DIV1,5000);
	PWMInit(PTA13,DIV1,5000);
	PWMInit(PTA5,DIV8,62500);
	
	Counter0_Init();
	Counter1_Init();
	
	
	ADC_userInit();
	PIT_userInit();
	GPIO_ResetBits(PTD,3);
	GPIO_ResetBits(PTD,4);
	GPIO_ResetBits(PTD,5);
	GPIO_ResetBits(PTD,6);
	
	PWMOutput(PTA12,2500);//�ҵ��
	PWMOutput(PTA13,2500);//����
	PWMOutput(PTA5,5400);//���
	ModelSwitch();
	StartDelay();
	
	
	while(1){
		//��ʱ��	ʱ��ͨ��PIT_userInit�޸�
		ITStatus state = PIT_GetITStatus(PIT0, PIT_IT_TIF);
		if(state == SET){
			PIT_ClearITPendingBit(PIT0, PIT_IT_TIF);
			//д����
			twinkleLed(PTB,0);
			CCD_Image_Process(Pixel);
			CCD_FAR_Image_Process(Pixel_Far);
			//Finish_flag = 1;
			directionControl();
			get_speed();
			speedControl();
			twinkleLed(PTB,0);
		}
		//Bluetooth���ͺ���
		/*if(Finish_flag == 1){
			Finish_flag = 0;
			if(++send_data_cnt >= 10){
				send_data_cnt = 0;
			  Send_Data(Pixel);
			}
		}
		if(Finish_flag == 1){
			Finish_flag = 0;
			if(++send_data_cnt >= 10){
				send_data_cnt = 0;
			  Send_Data(Pixel_Far);
			}
		}*/
	}

}
