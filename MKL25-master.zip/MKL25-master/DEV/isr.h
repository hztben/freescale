#ifndef __ISR_H__
#define __ISR_H__

#include "sys.h"


void configPIT(uint8_t PITx , uint32_t timePIT);

#endif 
